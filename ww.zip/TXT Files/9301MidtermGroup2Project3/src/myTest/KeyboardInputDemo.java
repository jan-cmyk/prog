package myTest;

import java.lang.*;
import java.io.*;
public class KeyboardInputDemo {
    public static void main(String[] args) {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int dividend=0, divisor=1;
        double quotient=0;
        try{
            System.out.print("Enter the dividend: ");
            System.out.flush();
            dividend = Integer.parseInt(br.readLine());
            System.out.println();
            System.out.print("Enter the divisor: ");
            System.out.flush();
            divisor = Integer.parseInt(br.readLine());
            System.out.println();
            quotient = (double) dividend/divisor;
            System.out.println("Quotient = " + quotient);
        }
        catch (NumberFormatException exception1){
            System.out.println("An invalid number was entered. Only whole numbers are allowed for now.");
            }
        catch (ArithmeticException exception2){
            System.out.println("Division by 0 is not allowed. The divisor must not be 0.");
        }
        catch (IOException exception3){
            System.out.println("A certain problem has been encountered.");
        }
        catch (Exception exception4){
            System.out.println("A certain problem has been encountered.");
        }
        finally {
            System.out.println("\n\nThere you go... ");
        } // end try catch finally }// end main } // end class
    }
}
