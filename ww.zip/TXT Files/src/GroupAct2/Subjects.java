package GroupAct2;

public class Subjects extends Profile{
    String[] subject1 = {"CFE 101 GOD'S JOURNEY WITH HIS PEOPLE", "CS 111 INTRODUCTION TO COMPUTING (LEC)",
            "CS 111L INTRODUCTION TO COMPUTING (LAB)", "CS 112 COMPUTER PROGRAMMING 1 (LEC)"
            , "CS 112L COMPUTER PROGRAMMING 1 (LAB)", "CS 113\tDISCRETE STRUCTURES",
            "FIT HW PHYSICAL ACTIVITY TOWARDS HEALTH AND FITNESS (HEALTH AND WELLNESS)", "GART ART APPRECIATION\t",
            "GHIST READINGS IN PHILIPPINE HISTORY", "GMATH MATHEMATICS IN THE MODERN WORLD\t"};
    Double [] grades1 ={0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0};

    String[] subject2 = {"CFE 102 CHRISTIAN MORALITY IN OUR TIMES\t", "CS 121 DIGITAL LOGIC DESIGN"
            ,"CS 122 COMPUTER PROGRAMMING", "CS 122L COMPUTER PROGRAMMING"
            ,"CS 123 ARCHITECTURE AND ORGANIZATION", "CS 123L ARCHITECTURE AND ORGANIZATION "
            ,"FIT CS\tPHYSICAL ACTIVITY TOWARDS HEALTH AND FITNESS (COMBATIVE SPORTS)", "GENVI ENVIRONMENTAL SCIENCE",
    "GPCOM PURPOSIVE COMMUNICATION ","GSELF UNDERSTANDING THE SELF ","131 SOFTWARE MODELING AND ANALYSIS","CS 132 MATHEMATICS FOR COMPUTER SCIENCE"};
    Double [] grades2 ={0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0};

   //  this stuff is to set your studsf
    public Double getGrade1(int x){
        return this.grades1[x];
    }
    public Double getGrade2(int x){  return this.grades2[x]; }
    public void setGrades1(int x,Double y){this.grades1[x] = y;}
    public void setGrades2(int x,Double y){this.grades2[x] = y;}




    public static void subjectList1() {
        System.out.println("");
        System.out.println("");
        System.out.println("==============================================");
        System.out.println("First Year, First Semester\n" +
                "CFE 101\tGOD'S JOURNEY WITH HIS PEOPLE\t3\n" +
                "CS 111\tINTRODUCTION TO COMPUTING (LEC)\t2\n" +
                "CS 111L\tINTRODUCTION TO COMPUTING (LAB)\t1\n" +
                "CS 112\tCOMPUTER PROGRAMMING 1 (LEC)\t2\n" +
                "CS 112L\tCOMPUTER PROGRAMMING 1 (LAB)\t1\n" +
                "CS 113\tDISCRETE STRUCTURES\t3\n" +
                "FIT HW\tPHYSICAL ACTIVITY TOWARDS HEALTH AND FITNESS (HEALTH AND WELLNESS)\t2\n" +
                "GART\tART APPRECIATION\t3\n" +
                "GHIST\tREADINGS IN PHILIPPINE HISTORY\t3\n" +
                "GMATH\tMATHEMATICS IN THE MODERN WORLD\t3\n" +
                "\n");
    }

    public static void subjectList2() {
        System.out.println("");
        System.out.println("");
        System.out.println("==============================================");
        System.out.println("First Year, Second Semester\n" +
                "CFE 102\tCHRISTIAN MORALITY IN OUR TIMES\t3\n" +
                "CS 121\tDIGITAL LOGIC DESIGN\t3\n" +
                "CS 122\tCOMPUTER PROGRAMMING 2\t2\n" +
                "CS 122L\tCOMPUTER PROGRAMMING 2 (LAB)\t1\n" +
                "CS 123\tARCHITECTURE AND ORGANIZATION\t2\n" +
                "CS 123L\tARCHITECTURE AND ORGANIZATION (LAB)\t1\n" +
                "FIT CS\tPHYSICAL ACTIVITY TOWARDS HEALTH AND FITNESS (COMBATIVE SPORTS)\t2\n" +
                "GENVI\tENVIRONMENTAL SCIENCE\t3\n" +
                "GPCOM\tPURPOSIVE COMMUNICATION\t3\n" +
                "GSELF\tUNDERSTANDING THE SELF\t3\n" +
                "\n" +
                "First Year, Short Term\n" +
                "CS 131\tSOFTWARE MODELING AND ANALYSIS\t3\n" +
                "CS 132\tMATHEMATICS FOR COMPUTER SCIENCE\t3\n" +
                "\n");
    }
}






// //here we can write stuff for the paper
//        try {
//            BufferedWriter writer = new BufferedWriter(new FileWriter("curriculum.txt"));
//        }catch (IOException e){
//            e.printStackTrace();
//        }
//
//        //this allows us to read the contents of the txt file
//        try {
//            BufferedReader reader = new BufferedReader(new FileReader("curriculum.txt"));
//        }catch (IOException e){
//            e.printStackTrace();
//        }
//
//        //reads the content of the console and well there you go
//        try {
//            BufferedReader console = new BufferedReader(new InputStreamReader(System.in));
//        }catch (Exception e){
//            e.printStackTrace();
//        }
