package GroupAct2;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Profile {
    //Helper method
    static boolean getYNCon(Scanner ggez, String pop){
        String respo = "";
        boolean result = false;
        do {
            //display
            System.out.print(pop + "[Yes/No]: ");
            respo = ggez.nextLine();
        }while (!respo.equalsIgnoreCase("Yes") && !respo.equalsIgnoreCase("No"));

        if(respo.equalsIgnoreCase("Yes"))
        {
            result = true;

        }
        return result;

    }

    //Add Course and Student
    private static void CourseName(){
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String CourseName = "";
        String StudName = "";
        Scanner gg = new Scanner(System.in);
        double Grade = 0;
        boolean CourseInput = false;
        double average = 0;
        File courseFile;
        PrintWriter out;
        ArrayList<String> courses = new ArrayList<>();
        ArrayList<Double> ggrades = new ArrayList<>();
        try
        {
            System.out.print("Please Enter Student Lastname and Firstname: ");
            StudName = gg.nextLine();
            //loop to get the students name in the arraylist
            do
            {
                System.out.print("Enter what course (Computer Programing 111) : ");
                CourseName = gg.nextLine();
                courses.add(CourseName);

                System.out.print("Enter Grade: ");
                Grade = Double.parseDouble(br.readLine());
                ggrades.add(Grade);

                //Continuation
                if(!getYNCon(gg, "Enter Another Course? "))
                {
                    CourseInput = true;
                }
            }while(!CourseInput);


         //this si wehre the stuff got printed earlier
        }
        catch (FileNotFoundException ez)
        {
            System.out.println("ERROR! Could not create output file");
            System.exit(0);
        }
        catch (IOException ez)
        {
            ez.getStackTrace();
            System.exit(0);
        }
        display(courses,ggrades);
        addGrades(ggrades);
    }
    private static void addGrades(ArrayList<Double> gradesExtra){
        Scanner scan = new Scanner(System.in);
        double average = 0.0;
        double prelim = 0;
        double midterm = 0;
        double finals = 0;

        System.out.println("Enter Prelim Grade" + prelim);
        prelim = scan.nextDouble();
        System.out.println("Enter Midterm Grade" + midterm);
        midterm = scan.nextDouble();
        System.out.println("Enter Final Grade" + finals);
        finals = scan.nextDouble();

        average = (prelim * .30) + (midterm * .30) + (finals * .40);
        for (int x = 0; x < gradesExtra.size();x++){
            average += gradesExtra.get(x);
            //use .get with array list to work properly
        }

        Double totalAverage = prelim+midterm+finals;

        System.out.print("Your General Weighted Average is: " + totalAverage);
    }
    private static void display(ArrayList<String> courses,ArrayList<Double> grades){
        for (int x = 0; x < courses.size(); x++){
            //use .size for array list
            System.out.println(courses.get(x) + " "+ grades.get(x));

        }

    }

}
//   //creates file and stores the names
//            courseFile = new File(CourseName + ".txt");
//            out = new PrintWriter(courseFile);
//
//            //header
//            out.println(CourseName);
//
//            //writes the name to file
//            for(String cnam : courses)
//            {
//                out.println(cnam);
//            }
//
//            //writes the arraylist to file
//            out.close();
