package GroupAct2;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Main extends Subjects {
    public static void main(String[] args) {
        int choice = 0;
        Subjects bob = new Subjects();
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        try {
            BufferedWriter bw = new BufferedWriter(
                    new FileWriter("C:\\Users\\Harlee\\Downloads\\out.txt"));
            do {
                showMenu();
                choice = enterChoice(1, 6);
                switch (choice) {
                    case 1:
                        confrim1(bob);
                        break;
                    case 2:
                        confrim2(bob);
                        break;
                    case 3:
                        double average1 = 0.0;
                        double average2 = 0.0;
                        System.out.println("");
                        System.out.println("==============================================");
                        System.out.println("");
                        for (int a = 0; a < bob.subject1.length; a++) {
                            System.out.println(bob.subject1[a] + " " + bob.getGrade1(a));
                        }

                        for (int x = 0; x < bob.subject1.length; x++) {
                            average1 += bob.grades1[x];
                        }
                        average1 = average1 / bob.subject1.length;

                        System.out.println("");
                        System.out.println("General weighted average: " + average1);
                        System.out.println("==============================================");
                        System.out.println("");
                        for (int b = 0; b < bob.subject2.length; b++) {
                            System.out.println(bob.subject2[b] + " " + bob.getGrade2(b));
                        }

                        for (int x = 0; x < bob.subject2.length; x++) {
                            average2 += bob.grades2[x];
                        }
                        average2 = average2 / bob.subject2.length;

                        System.out.println("");
                        System.out.println("General weighted average: " + average2);
                        System.out.println("==============================================");
                        System.out.println("");
                        break;
                    case 4:
                        profile();
                        break;
                    case 5:
                        printStuff1(bob.subject1, bob.grades1, bob.subject2, bob.grades2);
                        break;
                    case 6:
                        System.exit(0);
                        break;
                }
            } while (choice != 6);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void printStuff1(String[] subject1, Double[] grades1, String[] subject2, Double[] grades2) {
        {
            System.out.println("COLLEGE GRADE PRINTER 9000 ");
            System.out.println("NOW PRINTING ......");
            System.out.println("BRRRT BRRT BRRRT");
            double average1 = 0.0;
            double average2 = 0.0;

            for (int x = 0; x < subject1.length; x++) {
                average1 += grades1[x];
            }
            average1 = average1 / subject1.length;

            for (int x = 0; x < subject2.length; x++) {
                average2 += grades2[x];
            }
            average2 = average2 / subject2.length;
            try {

                BufferedWriter grades = new BufferedWriter(new FileWriter("output.txt"));
                grades.write("\n");
                grades.write("\n=======================================================================");
                grades.write("\n");
                grades.write("\nBachelor of Computer Science");
                //use .length for regular arrays
                grades.write("\n1st year 1st Semester");

                for (int x = 0; x < subject1.length; x++) {
                    grades.write("\n" + subject1[x] + ": " + grades1[x]);
                }
                grades.write("\n");
                grades.write("\nGeneral weighted average: " + average1);
                grades.write("\n=======================================================================");
                grades.write("\n");
                grades.write("\n1st year 2nd Semester");

                for (int x = 0; x < subject2.length; x++) {
                    grades.write("\n" + subject2[x] + ": " + grades2[x]);
                }
                grades.write("\n");
                grades.write("\nGeneral weighted average: " + average2);
                grades.write("\n=======================================================================");
                grades.write("\n");


                grades.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    public static void profile() {
        Scanner scan = new Scanner(System.in);
        String CourseName = "";
        String StudName = "";
        double gradesExtra = 0;
        double Grade = 0;
        boolean CourseInput = false;
        double average = 0;
        File courseFile;
        PrintWriter out;
        Scanner gg = new Scanner(System.in);
        ArrayList<String> courses = new ArrayList<>();
        ArrayList<Double> ggrades = new ArrayList<>();

        System.out.print("Please Enter Student Lastname and Firstname: ");
        StudName = gg.nextLine();

        try {
            //loop to get the students name in the arraylist
            do {
                System.out.print("Enter what course (Computer Programing 111) : ");
                CourseName = gg.nextLine();
                courses.add(CourseName);

                System.out.print("Enter Class Code: ");
                Grade = gg.nextDouble();
                ggrades.add(Grade);

                double midterm = 0;
                double prelim = 0;
                double finals = 0;

                System.out.println("Enter Prelim Grade: " );
                prelim = scan.nextDouble();
                System.out.println("Enter Midterm Grade: " );
                midterm = scan.nextDouble();
                System.out.println("Enter Final Grade: " );
                finals = scan.nextDouble();

                average = (prelim * .30) + (midterm * .30) + (finals * .40);

                Double totalAverage = prelim + midterm + finals;
                Grade = totalAverage/3;

                System.out.print("Your General Weighted Average is: " + Grade);

                //Continuation
                if (!Profile.getYNCon(gg, "\n Enter Another Course? ")) {
                    CourseInput = true;
                }
            } while (!CourseInput);

            //creates file and stores the names
            courseFile = new File(CourseName + "Course.txt");
            out = new PrintWriter(courseFile);

            //header
            out.println(CourseName);

            //writes the name to file
            for (String cnam : courses) {
                out.println(cnam);
            }

            //writes the arraylist to file
            out.close();
        } catch (FileNotFoundException ez) {
            System.out.println("ERROR! Could not create output file");
            System.exit(0);
        } catch (IOException ez) {
            ez.getStackTrace();
            System.exit(0);
        }

    }

    public static void showMenu() {
        System.out.println("Enter the number which you would like to access");
        System.out.println("1.Enrollment and input of grades for the  1st sem");
        System.out.println("2.Enrollment and input of grades for the 2nd sem");
        System.out.println("3.View all courses and grades for 1st and 2nd sem");
        System.out.println("4.Input personal name and Enrollment in extra courses");
        System.out.println("5.Print the grades and courses for 1st and 2nd sem in a separate file");
        System.out.println("6.Close the program");
    }

    public static int enterChoice(int min, int max) {
        Scanner kbd = new Scanner(System.in);
        int choice = 0;
        do {
            System.out.print("Input the number corresponding to your choice: ");
            choice = kbd.nextInt();
            if (choice < min || choice > max)
                System.out.println("Invalid choice. Please ensure that you enter a number from " +
                        min + " to " + max + ".");
        } while (choice < min || choice > max);
        return (choice);
    }

    public static void confrim1(Subjects bob) {
        Scanner kbd = new Scanner(System.in);
        String text1 = null;
        Character text2 = null;
        Character text3 = 'y';
        Character text4 = 'n';

        //prints out the whole list of stuff
        //takes the input for it
        try {
            System.out.println("These are the subjects that you are required to take for the 1st sem of 1st year");
            subjectList1();
            System.out.println("Do you still wish to enroll in these classes ?");
            System.out.println("y/n ?");
            text1 = kbd.nextLine();
            text2 = text1.charAt(0);
        } catch (Exception e) {
            e.printStackTrace();
        }

        //checks whether you have enrolled for this sem
        //if yes then you set the grades
        if (text2 == text3) {
            Integer x;
            for (x = 0; x < bob.subject1.length; x++) {
                System.out.println("Enter the grade for: " + bob.subject1[x] + ":");
                bob.setGrades1(x, kbd.nextDouble());
            }

            //if no then you skip
        } else if (text2 == text4) {
            System.out.println("You will not be enrolled for these subjects");
            System.out.println("Enter any key to continue");
            kbd.nextLine();
        }


    }

    public static void confrim2(Subjects bob) {
        Scanner kbd = new Scanner(System.in);
        String text1 = null;
        Character text2 = null;
        Character text3 = 'y';
        Character text4 = 'n';

        //prints out the whole list of stuff
        //takes the input for it
        try {
            text1 = "n";
            text2 = 'n';
            System.out.println("These are the subjects that you are required to take for the 2nd sem of 1st year");
            subjectList2();
            System.out.println("Do you still wish to enroll in these classes ?");
            System.out.println("y/n ?");
            text1 = kbd.nextLine();
            text2 = text1.charAt(0);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (text2 == text3) {
            Integer x;
            for (x = 0; x < bob.subject2.length; x++) {
                System.out.println("Enter the grade for: " + bob.subject2[x] + " : ");
                bob.setGrades2(x, kbd.nextDouble());
            }
            //if no then you skip
        } else if (text2 == text4) {
            System.out.println("You will not be enrolled for these subjects");
            System.out.println("Enter any key to continue");
            kbd.nextLine();
        }
    }

}
